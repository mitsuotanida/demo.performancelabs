# Performance Labs — Checklist Google Ads, GA4 y GTM

Este paquete ya viene preparado para medir intención de prospectos, apertura de demo y conversión por página de gracias.

## Archivos clave

- `index.html`: landing principal con botón **Ver demo interactiva**.
- `demo.html`: demo en página completa.
- `performance_dashboard.html`: dashboard interactivo embebible.
- `diagnostico.html`: página puente para solicitar diagnóstico.
- `thank-you.html`: página de gracias preparada para conversión.
- `app.js`: eventos `dataLayer` para GTM / GA4 / Google Ads.

## 1. Reemplazar el ID de Google Tag Manager

Busca en todos los `.html`:

```html
GTM-XXXXXXX
```

Reemplázalo por tu contenedor real, por ejemplo:

```html
GTM-ABC1234
```

## 2. Eventos que ya empuja el sitio

El sitio manda estos eventos al `dataLayer`:

| Evento | Cuándo ocurre | Uso recomendado |
|---|---|---|
| `pl_page_view` | Al cargar cada página | Medición base |
| `demo_open` | Al abrir el modal de demo | Microconversión |
| `demo_close` | Al cerrar el modal de demo | Análisis de interacción |
| `lead_intent` | Al hacer clic en diagnóstico/formulario | Conversión de intención |
| `lead_cta_click` | Clics a CTA configurados | Compatibilidad con versión anterior |
| `lead_form_submit_success` | Al llegar a `thank-you.html` | Conversión principal |

## 3. Configuración recomendada en GTM

Crea estos triggers de tipo **Custom Event**:

1. `demo_open`
2. `lead_intent`
3. `lead_form_submit_success`

Luego crea etiquetas GA4 Event:

| GA4 Event name | Trigger |
|---|---|
| `demo_open` | Custom event `demo_open` |
| `generate_lead_intent` | Custom event `lead_intent` |
| `generate_lead` | Custom event `lead_form_submit_success` |

## 4. Conversión principal para Google Ads

La conversión más limpia es la visita a:

```text
/thank-you.html
```

En GA4 marca como conversión/key event el evento:

```text
generate_lead
```

Luego importa esa conversión desde Google Ads.

## 5. Google Forms y página de gracias

El sitio usa Google Forms como capturador inicial de prospectos.

Para medir envío real, tienes dos caminos:

### Camino rápido
En el mensaje de confirmación del Google Form, agrega un link visible a:

```text
https://TU-DOMINIO/thank-you.html
```

Texto sugerido:

```text
Gracias por completar el diagnóstico. Haz clic aquí para confirmar tu solicitud: https://TU-DOMINIO/thank-you.html
```

### Camino pro
Migrar el formulario a un endpoint propio o servicio compatible con redirección automática. El destino posterior al envío debe ser:

```text
/thank-you.html
```

## 6. URLs recomendadas para campaña

| Uso | URL |
|---|---|
| Landing principal | `/index.html` |
| Demo interactiva | `/demo.html` |
| Captura de prospecto | `/diagnostico.html` |
| Conversión final | `/thank-you.html` |

## 7. Prueba antes de lanzar

1. Publica el sitio en GitHub Pages.
2. Abre GTM Preview.
3. Entra a la landing.
4. Haz clic en **Ver demo interactiva**.
5. Revisa que aparezca `demo_open`.
6. Haz clic en **Solicitar diagnóstico**.
7. Revisa que aparezca `lead_intent`.
8. Abre `/thank-you.html`.
9. Revisa que aparezca `lead_form_submit_success`.
10. Verifica eventos en GA4 Realtime.

## 8. Nota importante

Con Google Forms externo, Google Ads puede medir muy bien clics e intención. Para medir el envío real sin fricción, necesitas usar `thank-you.html` como destino final posterior al envío del formulario.
