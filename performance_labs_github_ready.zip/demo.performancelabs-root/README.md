# Performance Labs MVP — listo para GitHub Pages

Sitio estático preparado para mostrar una landing comercial, una demo interactiva embebida y un flujo base de captación de prospectos.

## Páginas incluidas

- `index.html` — Inicio / landing principal.
- `demo.html` — Demo interactiva en pantalla completa.
- `performance_dashboard.html` — Dashboard interactivo usado dentro del modal y la página demo.
- `diagnostico.html` — Página puente para solicitar diagnóstico.
- `thank-you.html` — Página de gracias lista para medición de conversión.
- `quienes-somos.html` — Página institucional.
- `mision-vision.html` — Misión y visión.
- `valores-sellos.html` — Valores y sellos.
- `404.html` — Página de error.

## Cómo publicar en GitHub Pages

1. Sube todos los archivos del paquete al repositorio.
2. En GitHub ve a **Settings → Pages**.
3. Selecciona rama `main` y carpeta raíz.
4. Espera la publicación.
5. Abre tu dominio o URL de GitHub Pages.

## Demo interactiva

La landing incluye un botón **Ver demo interactiva**. Al hacer clic, se abre un modal con `performance_dashboard.html` embebido en un iframe.

También existe una página completa:

```text
/demo.html
```

## Captura de prospectos

Los CTAs apuntan a:

```text
/diagnostico.html
```

Desde ahí el usuario puede abrir el Google Form actual. La página `thank-you.html` queda preparada para medir conversión real cuando configures redirección o confirmación desde el formulario.

## Google Ads / GA4 / GTM

El sitio ya incluye placeholders de Google Tag Manager. Reemplaza en todos los `.html`:

```text
GTM-XXXXXXX
```

por tu ID real de GTM.

Eventos listos en `dataLayer`:

- `pl_page_view`
- `demo_open`
- `demo_close`
- `lead_intent`
- `lead_cta_click`
- `lead_form_submit_success`

Más detalle en:

```text
GOOGLE_ADS_SETUP.md
```

## Personalizaciones rápidas

- Cambiar URL del Google Form: editar `APP_CONFIG.formUrl` en `app.js` y los botones de `diagnostico.html`.
- Cambiar dominio: editar `CNAME`.
- Cambiar estilos globales: editar `styles.css`.
- Cambiar dashboard demo: reemplazar `performance_dashboard.html`.
