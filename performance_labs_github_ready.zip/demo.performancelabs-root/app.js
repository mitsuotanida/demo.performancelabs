const APP_CONFIG = {
  formUrl: "https://forms.gle/Sb2u6RuwZ6XTGvu79",
  siteName: "Performance Labs",
  offer: "Diagnóstico inicial sin costo"
}; // Este objeto concentra la configuración principal del sitio. Sirve para cambiar la URL del formulario o el nombre del proyecto desde un solo lugar.

function setActiveNav() {
  const path = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('[data-page]').forEach((link) => {
    if (link.getAttribute('data-page') === path) {
      link.classList.add('is-active');
    }
  });
}

function enhanceExternalLinks() {
  const externalLinks = document.querySelectorAll('a[target="_blank"]');

  externalLinks.forEach((link) => {
    const currentRel = link.getAttribute('rel') || '';
    const relParts = currentRel.split(' ').filter(Boolean);

    if (!relParts.includes('noopener')) relParts.push('noopener');
    if (!relParts.includes('noreferrer')) relParts.push('noreferrer');

    link.setAttribute('rel', relParts.join(' '));
  });
}

function attachLeadTrackingPlaceholders() {
  const ctaLinks = document.querySelectorAll('a[href="' + APP_CONFIG.formUrl + '"]');

  ctaLinks.forEach((link) => {
    link.addEventListener('click', () => {
      window.dataLayer = window.dataLayer || [];
      window.dataLayer.push({
        event: 'lead_cta_click',
        site: APP_CONFIG.siteName,
        offer: APP_CONFIG.offer,
        button_text: link.textContent.trim()
      });
    });
  });
}

function initApp() {
  setActiveNav();
  enhanceExternalLinks();
  attachLeadTrackingPlaceholders();
}

document.addEventListener('DOMContentLoaded', initApp);

function pushTrackingEvent(eventName, payload = {}) {
  window.dataLayer = window.dataLayer || [];
  window.dataLayer.push({ event: eventName, ...payload });
} // Este objeto/evento manda información a Google Tag Manager. Sirve para medir clics, demo y prospectos sin tocar cada botón manualmente.

function initDemoModal() {
  const modal = document.getElementById('demoModal');
  const openButtons = document.querySelectorAll('[data-demo-open]');
  const closeButtons = document.querySelectorAll('[data-demo-close]');

  if (!modal || !openButtons.length) return;

  const openModal = () => {
    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
    pushTrackingEvent('demo_open', {
      demo_name: 'performance_dashboard_embedded',
      page_path: window.location.pathname
    });
  };

  const closeModal = () => {
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    pushTrackingEvent('demo_close', {
      demo_name: 'performance_dashboard_embedded',
      page_path: window.location.pathname
    });
  };

  openButtons.forEach((button) => button.addEventListener('click', openModal));
  closeButtons.forEach((button) => button.addEventListener('click', closeModal));

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && modal.classList.contains('is-open')) {
      closeModal();
    }
  });
} // Esta función abre y cierra el panel demo. Sirve para que el prospecto interactúe con el dashboard embebido sin salir de la landing.

function attachProspectTracking() {
  const leadLinks = document.querySelectorAll('a[href="./diagnostico.html"], [data-lead-form-link]');

  leadLinks.forEach((link) => {
    link.addEventListener('click', () => {
      pushTrackingEvent('lead_intent', {
        cta_text: link.textContent.trim(),
        cta_url: link.getAttribute('href'),
        page_path: window.location.pathname
      });
    });
  });
} // Esta función mide intención de prospecto. Sirve para conectar eventos de la landing con GA4 y Google Ads.

function initEnhancedApp() {
  initDemoModal();
  attachProspectTracking();
} // Este objeto de inicialización agrupa las mejoras nuevas. Sirve para mantener el código ordenado.

document.addEventListener('DOMContentLoaded', initEnhancedApp);
